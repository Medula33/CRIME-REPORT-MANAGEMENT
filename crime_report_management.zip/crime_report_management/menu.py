class Menu:
    @staticmethod
    def display_menu():
        print("\nCrime Report Management System")
        print("1. Report a Crime")
        print("2. View Crime Reports")
        print("3. Delete a Crime Report")
        print("4. View Summary of Crimes by Location")
        print("5. Exit")
